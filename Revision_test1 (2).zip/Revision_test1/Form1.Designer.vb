﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdbKuching = New System.Windows.Forms.RadioButton()
        Me.rdbSeoul = New System.Windows.Forms.RadioButton()
        Me.rdbDubai = New System.Windows.Forms.RadioButton()
        Me.rdbPenang = New System.Windows.Forms.RadioButton()
        Me.rdbLondon = New System.Windows.Forms.RadioButton()
        Me.rdbSydney = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCALC = New System.Windows.Forms.Button()
        Me.chkTourist = New System.Windows.Forms.CheckBox()
        Me.chkHoneymoon = New System.Windows.Forms.CheckBox()
        Me.chkReturn = New System.Windows.Forms.CheckBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(94, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(94, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Phone no"
        '
        'txtName
        '
        Me.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtName.Location = New System.Drawing.Point(251, 46)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(305, 22)
        Me.txtName.TabIndex = 2
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPhoneNumber.Location = New System.Drawing.Point(251, 87)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(305, 22)
        Me.txtPhoneNumber.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdbKuching)
        Me.GroupBox1.Controls.Add(Me.rdbSeoul)
        Me.GroupBox1.Controls.Add(Me.rdbDubai)
        Me.GroupBox1.Controls.Add(Me.rdbPenang)
        Me.GroupBox1.Controls.Add(Me.rdbLondon)
        Me.GroupBox1.Controls.Add(Me.rdbSydney)
        Me.GroupBox1.Location = New System.Drawing.Point(87, 138)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(574, 180)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Destination"
        '
        'rdbKuching
        '
        Me.rdbKuching.AutoSize = True
        Me.rdbKuching.Location = New System.Drawing.Point(380, 125)
        Me.rdbKuching.Name = "rdbKuching"
        Me.rdbKuching.Size = New System.Drawing.Size(128, 20)
        Me.rdbKuching.TabIndex = 5
        Me.rdbKuching.TabStop = True
        Me.rdbKuching.Text = "Kuching (RM399)"
        Me.rdbKuching.UseVisualStyleBackColor = True
        '
        'rdbSeoul
        '
        Me.rdbSeoul.AutoSize = True
        Me.rdbSeoul.Location = New System.Drawing.Point(380, 78)
        Me.rdbSeoul.Name = "rdbSeoul"
        Me.rdbSeoul.Size = New System.Drawing.Size(123, 20)
        Me.rdbSeoul.TabIndex = 4
        Me.rdbSeoul.TabStop = True
        Me.rdbSeoul.Text = "Seoul (RM1499)"
        Me.rdbSeoul.UseVisualStyleBackColor = True
        '
        'rdbDubai
        '
        Me.rdbDubai.AutoSize = True
        Me.rdbDubai.Location = New System.Drawing.Point(380, 35)
        Me.rdbDubai.Name = "rdbDubai"
        Me.rdbDubai.Size = New System.Drawing.Size(124, 20)
        Me.rdbDubai.TabIndex = 3
        Me.rdbDubai.TabStop = True
        Me.rdbDubai.Text = "Dubai (RM1299)"
        Me.rdbDubai.UseVisualStyleBackColor = True
        '
        'rdbPenang
        '
        Me.rdbPenang.AutoSize = True
        Me.rdbPenang.Location = New System.Drawing.Point(31, 125)
        Me.rdbPenang.Name = "rdbPenang"
        Me.rdbPenang.Size = New System.Drawing.Size(128, 20)
        Me.rdbPenang.TabIndex = 2
        Me.rdbPenang.TabStop = True
        Me.rdbPenang.Text = "Penang (RM199)"
        Me.rdbPenang.UseVisualStyleBackColor = True
        '
        'rdbLondon
        '
        Me.rdbLondon.AutoSize = True
        Me.rdbLondon.Location = New System.Drawing.Point(31, 78)
        Me.rdbLondon.Name = "rdbLondon"
        Me.rdbLondon.Size = New System.Drawing.Size(133, 20)
        Me.rdbLondon.TabIndex = 1
        Me.rdbLondon.TabStop = True
        Me.rdbLondon.Text = "London (RM1899)"
        Me.rdbLondon.UseVisualStyleBackColor = True
        '
        'rdbSydney
        '
        Me.rdbSydney.AutoSize = True
        Me.rdbSydney.Location = New System.Drawing.Point(31, 35)
        Me.rdbSydney.Name = "rdbSydney"
        Me.rdbSydney.Size = New System.Drawing.Size(134, 20)
        Me.rdbSydney.TabIndex = 0
        Me.rdbSydney.TabStop = True
        Me.rdbSydney.Text = "Sydney (RM1499)"
        Me.rdbSydney.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnExit)
        Me.GroupBox2.Controls.Add(Me.btnClear)
        Me.GroupBox2.Controls.Add(Me.btnCALC)
        Me.GroupBox2.Controls.Add(Me.chkTourist)
        Me.GroupBox2.Controls.Add(Me.chkHoneymoon)
        Me.GroupBox2.Controls.Add(Me.chkReturn)
        Me.GroupBox2.Location = New System.Drawing.Point(87, 347)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(574, 180)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Detail"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(399, 118)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(141, 31)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(399, 69)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(141, 31)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCALC
        '
        Me.btnCALC.Location = New System.Drawing.Point(399, 21)
        Me.btnCALC.Name = "btnCALC"
        Me.btnCALC.Size = New System.Drawing.Size(141, 31)
        Me.btnCALC.TabIndex = 3
        Me.btnCALC.Text = "Calculate"
        Me.btnCALC.UseVisualStyleBackColor = True
        '
        'chkTourist
        '
        Me.chkTourist.AutoSize = True
        Me.chkTourist.Location = New System.Drawing.Point(31, 118)
        Me.chkTourist.Name = "chkTourist"
        Me.chkTourist.Size = New System.Drawing.Size(162, 20)
        Me.chkTourist.TabIndex = 2
        Me.chkTourist.Text = "Tourist Guide (RM500)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkTourist.UseVisualStyleBackColor = True
        '
        'chkHoneymoon
        '
        Me.chkHoneymoon.AutoSize = True
        Me.chkHoneymoon.Location = New System.Drawing.Point(31, 75)
        Me.chkHoneymoon.Name = "chkHoneymoon"
        Me.chkHoneymoon.Size = New System.Drawing.Size(222, 20)
        Me.chkHoneymoon.TabIndex = 1
        Me.chkHoneymoon.Text = "Honeymoon Trip (Discount 30%)"
        Me.chkHoneymoon.UseVisualStyleBackColor = True
        '
        'chkReturn
        '
        Me.chkReturn.AutoSize = True
        Me.chkReturn.Location = New System.Drawing.Point(31, 34)
        Me.chkReturn.Name = "chkReturn"
        Me.chkReturn.Size = New System.Drawing.Size(108, 20)
        Me.chkReturn.TabIndex = 0
        Me.chkReturn.Text = "Return Ticket"
        Me.chkReturn.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft YaHei", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(437, 544)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(51, 23)
        Me.lblTotal.TabIndex = 7
        Me.lblTotal.Text = "Total"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 586)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtPhoneNumber)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Travel Calculator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtPhoneNumber As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rdbSydney As RadioButton
    Friend WithEvents rdbKuching As RadioButton
    Friend WithEvents rdbSeoul As RadioButton
    Friend WithEvents rdbDubai As RadioButton
    Friend WithEvents rdbPenang As RadioButton
    Friend WithEvents rdbLondon As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkHoneymoon As CheckBox
    Friend WithEvents chkReturn As CheckBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCALC As Button
    Friend WithEvents chkTourist As CheckBox
    Friend WithEvents lblTotal As Label
End Class
